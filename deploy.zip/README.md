# healthify-wealthify-service

## to run service
npm install
npm start